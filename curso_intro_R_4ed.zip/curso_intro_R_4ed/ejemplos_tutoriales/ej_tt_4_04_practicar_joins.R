#-------- ejemplo para practicar joins de df's

library("tidyverse")


#------------------ 2 casos sencillos
df1 <- iris
df2 <- iris
df <- rbind(df1, df2) #- juntamos las rows de los dos dfs 

df1 <- iris %>% select(1:2, 5)
df2 <- iris %>% select(3:ncol(iris))
df <- cbind(df1, df2)      #- juntamos las columnas de df_esp_1 y df_esp_2 (Species aparece 2 veces y con el mismo nombre)
df <- bind_cols(df1, df2)  #- juntamos las columnas de df_esp_1 y df_esp_2

rm(df, df1, df2)  #- borramos objetos


#------------------ MUTATING joins (se usan, principalmente, para añadir columnas)
df1 <- data_frame(x = c(1, 2), y = 2:1)
df2 <- data_frame(x = c(1, 3), a = 10, b = "a")


#- inner_join(df1, df2) 
#- only includes observations that match in both df1 and df2.
df_inner <- inner_join(df1, df2, by = "x")


#- left_join(df1, df2) 
#- includes all observations in df1, regardless of whether they match or not. 
#- This is the most commonly used join because it ensures that you don’t lose observations from your primary table.
df_left_join <- left_join(df1, df2)


#- right_join(df1, df2) 
#- includes all observations in df2. 
#- It’s equivalent to left_join(df2, df1), but the columns will be ordered differently.
df_right_join <- right_join(df1, df2)


#- full_join() includes all observations from df1 and df2
df_full_join <- full_join(df1, df2)



#- 2 precisiones sobre las mutating joins
#- Las mutating joins se usan principalmente para añadir columnas, **PERO** en el proceso pueden generarse nuevas filas: 
#- si un match no es único, se añadirán todas las combinaciones posibles (el producto cartesiano) de las matching observations. Veamos un ejemplo con una left_join
(df1 <- data_frame(x = c(1, 1, 2), y = 1:3))
(df2 <- data_frame(x = c(1, 1, 2), z = c("a", "b", "a")))
df_left_join <- left_join(df1, df2)
df_left_join


#------------------ FILTERING joins (hacen machting con las filas de la misma manera, PERO afectan a las filas, NO a las columnas)

df1 <- data_frame(V1 = c(1, 1, 3, 4), V2 = 1:4)
df2 <- data_frame(V1 = c(1, 1, 2), V3 = c("a", "b", "a"))

#- semi-join (retorna las observaciones de df1 que tienen un match en df2. Sólo retorna las columnas de df1)
df_semi_join <-  semi_join(df1, df2, by = "V1")


#- anti-join (retorna las observaciones de df1 que NO tienen un match en df2. Sólo retorna las columnas de df1)
df_anti_join <-  anti_join(df1, df2, by = "V1")





#------------------ SET operations (hace falta que los 2 df’s tengan las mismas variables (o columnas))
df1 <- data_frame(x = 1:2, y = c(1L, 1L))
df2 <- data_frame(x = 1:2, y = 1:2)


#- interseccion
df_intersect <- intersect(df1, df2)

#- union
df_union <- union(df1, df2)      #- devuelve la union (quitando los duplicados)
df_union <- union_all(df1, df2)  #- devuelve la unión (sin quitar los duplicados)

#- setdiff
df_dif_1 <- setdiff(df1, df2)  #- devuelve las filas en df1 que no están en df2
df_dif_2 <- setdiff(df2, df1)  #- devuelve las filas en df2 que no están en df1

#- setequal retorna TRUE si df y df2 tienen exactamente las mismas filas (da igual el orden en el que estén las filas)
setequal(df1, df2)
setequal(union(df1, df2), union(df2, df1))


