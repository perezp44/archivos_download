#- Este post: https://www.r-bloggers.com/learning-and-teaching-r-get-to-the-plot/
#- dice es que para que la gente se "enganche" a R hay que hacerlo interesante desde el primer dia. Make R Useful on Day 1!!!
#- El autor se pregunta que es lo que atrae de R: ¿es el cryptic coding style “<-”?, ¿es the sexy statistical analysis?, ¿or something else?
#- El autor se responde diciendo : For me as the student and practitioner, R is an absolutely amazing communications tools:  Shiny, ggplot2 and Rmarkdown ...
#- entonces, Kenith Grey, recomienda: if you are learning or teaching R, I say to you, “Get to the plot!”. Make R Useful on Day 1!!
#- Además, .... ¿Cómo hace sus gráficos la BBC? https://medium.com/bbc-visual-and-data-journalism/how-the-bbc-visual-and-data-journalism-team-works-with-graphics-in-r-ed0b35693535
#------------------------------------------------------------------------------------------------------------------------------------

#- Nada, pues hagamos caso a Kenith Grey y vayamos directamente a los plots.
#- TAREA: Id a esta página web https://www.r-graph-gallery.com   , elige un plot, copia el código y haz que funcione.
#- Yo me decidí por este plot: https://www.r-graph-gallery.com/196-the-wordcloud2-library/



#install.packages("wordcloud2")
library(wordcloud2)

# have a look to the example dataset
aa <- demoFreq
wordcloud2(demoFreq, size = 1.6)

# Gives a proposed palette
wordcloud2(demoFreq, size = 1.6, color = 'random-dark')

# or a vector of colors. vector must be same length than input data
wordcloud2(demoFreq, size = 1.6, color = rep_len( c("green","blue"), nrow(demoFreq) ) )

# Change the background color
wordcloud2(demoFreq, size = 1.6, color= 'random-light', backgroundColor = "black")


# Change the shape:
wordcloud2(demoFreq, size = 0.7, shape = 'star')

wordcloud2(demoFreq, size = 0.7, shape = 'pentagon', color = "skyblue", backgroundColor="black")


# Change the shape using your image (no me funciona!!)
#wordcloud2(demoFreq, figPath = "./imagenes/peace.png", size = 1.5, color = "skyblue", backgroundColor="black")

#- mas ejemplos
ww <- wordcloud2(demoFreq, size = 2.3, minRotation = -pi/6, maxRotation = -pi/6, rotateRatio = 1)

wordcloud2(demoFreq, size = 2, fontFamily = "微软雅黑", color = "random-light", backgroundColor = "grey")


#- tampoco acaban de funcionar las letras (!!)
letterCloud( demoFreq, word = "R", color='random-light' , backgroundColor="black")
letterCloud( demoFreq, word = "PEACE", color="white", backgroundColor="pink", wordSize = 33)
