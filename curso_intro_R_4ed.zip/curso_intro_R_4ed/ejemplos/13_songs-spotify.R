#- http://mchow.com/posts/data-science-cbk/    ::Teaching Data Science to High Schoolers
#- spotify: https://github.com/machow/workshop-r-data-science/blob/master/workshop/example_spotify.R
#- https://github.com/machow/workshop-r-data-science
# devtools::install_github('JosiahParry/geniusR')
# devtools::install_github('charlie86/spotifyr')
# usethis::edit_r_environ()  #- he editado el enviroment guardando los SPOTIFY_CLIENT_ID y SPOTIFY_CLIENT_SECRET



#- https://r-music.rbind.io/posts/2018-10-01-rspotify/  (como crear appp)
#- https://www.r-bloggers.com/prophets-of-gloom-using-nlp-to-analyze-radiohead-lyrics/
#- https://peerchristensen.netlify.com/post/clustering-springsteen-albums-with-spotifyr/
#- https://www.chadbixby.com/2018/08/30/spotify/
  
  
library(spotifyr)
library(dplyr)
library(ggplot2)
library(plotly)

#- authentification in Spotify
#- You have to have an Dev account with Spotify (https://github.com/charlie86/spotifyr)
#Sys.setenv(SPOTIFY_CLIENT_ID = 'xxxxxxxxxxx')
#Sys.setenv(SPOTIFY_CLIENT_SECRET = 'xxxxxxxxxxx')
access_token <- get_spotify_access_token()

ls("package:spotifyr")  #- all the functions


#- Some queries to Spotify API
# artist <- get_artist_audio_features("The Beatles")
aa <- get_artists("Nacho")
artist <- "Nacho vegas"  #- "The Beatles"

aa1 <- get_artist_audio_features(artist)
aa2 <- get_artist_albums(artist)
aa3 <- get_discography(artist) #- tiene las letras
aa4 <- get_related_artists(artist)

#- album 
albums <- get_artist_albums(artist)
albums_popularity <- get_album_popularity(albums)
aa <- full_join(albums_popularity, albums) 


bb2 <- get_album_data(artist, albums = "Actos Inexplicables")  #- 
bb3 <- get_album_tracks(albums)


#- user playlist
bb <- get_user_playlists("perezp44")

#- user playlist
user <- 'barackobama'  #- 'barackobama'
user_playlists <- get_user_playlists(user)
user_play_songs <- get_playlist_tracks(user_playlists)
#cc <- get_user_audio_features(user, show_progress = TRUE)

# view data -------------------------------------------------------------------
# drop some uneccessary columns, and sort by popularity (higher is more popular)
aa1 %>%
  select(-album_uri, -album_img, -track_uri, -track_preview_url) %>%
  arrange(track_popularity) %>% select(track_name, album_name, track_popularity, everything()) %>% 
  View()

# energy vs valence -----------------------------------------------------------
# get only 1 album, store result as "album"
album <- aa1 %>%
  filter(album_name == "Resituación") %>%
  select(album_name, track_name, energy, valence, track_popularity)

# make a scatterplot of energy vs valence
p <- ggplot(album) +
  geom_point(aes(x = energy, y = valence)) +
  geom_text(aes(x = energy, y = valence, label = track_name),
            hjust = 'left', size = 2, nudge_x = .01)

ggplotly(p)

# song year vs popularity -----------------------------------------------------

ggplot(aa1) +
  geom_point(aes(album_release_year, track_popularity, color = album_name, annotate=track_name))

ggplotly()

# view other song features ----------------------------------------------------
library(tidyr)
top6 <- aa1 %>%
  arrange(desc(track_popularity)) %>%
  top_n(6) %>%
  select(track_name, danceability, energy, speechiness, valence) %>%
  gather(sentiment, value, -track_name)

ggplot(top6) +
  geom_col(aes(sentiment, value, fill = sentiment)) +
  facet_wrap(~track_name) + theme(axis.text.x = element_blank())




#- conseguir letras --------------------------
# https://github.com/JosiahParry/geniusR

library(geniusR)
library(tidyverse) # For manipulation

emotions_math <- genius_album(artist = "Margaret Glaspy", album = "Emotions and Math")
emotions_math <- genius_album(artist = "Nacho Vegas", album = "Actos inexplicables")


memory_street <- genius_lyrics(artist = "Margaret Glaspy", song = "Memory Street")

aa <- genius_tracklist(artist = "Nacho Vegas", album = "Actos inexplicables") 



# https://www.hvitfeldt.me/2018/04/ggpage-version-0-2-0-showcase/   (para el Quijote)
  
  
#- word cloud ----------------------------------------------
library(tidytext)
library(stringr)
library(wordcloud2)
library(tm)  #- stopwords("spanish")


emotions_math <- genius_album(artist = "Nacho Vegas", album = "Actos inexplicables")



#Unnest the words - code via Tidy Text
hmtTable <- emotions_math %>% 
  unnest_tokens(word, lyric)

#remove stop words - aka typically very common words such as "the", "of" etc
esp_stop <- stopwords("spanish") %>% as.data.frame() 
names(esp_stop) <- "word"

hmtTable <- hmtTable %>%
  anti_join(esp_stop)     # stop_words


#do a word count
hmtTable <- hmtTable %>%
  count(word, sort = TRUE) 
hmtTable 

#Remove other nonsense words
hmtTable <- hmtTable %>%
  filter(!word %in% c('t.co', 'https', 'handmaidstale', "handmaid's", 'season', 'episode', 'de', 'handmaidsonhulu',  'tvtime', 
                      'watched', 'watching', 'watch', 'la', "it's", 'el', 'en', 'tv',
                      'je', 'ep', 'week', 'amp'))

wordcloud2(hmtTable, size = 0.7)
