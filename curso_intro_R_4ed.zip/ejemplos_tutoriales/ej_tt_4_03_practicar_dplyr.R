library(tidyverse)
library(gapminder)

# vamos a trabajar con los datos del [pkg gapminder](https://github.com/jennybc/gapminder)
df <- gapminder

##------------------------------------------------ Filtrar filas con CONDICIONES: filter()

#- Observaciones de España (country == "Spain")
aa <- df %>% filter(country == "Spain")

#- filas con valores de "lifeExp" < 29
aa <- df %>% filter(lifeExp < 29)

#- filas con valores de "lifeExp" entre [29, 32]
aa <- df %>% filter(lifeExp >=  29 , lifeExp <= 32)
aa <- df %>% filter(lifeExp >=  29 &  lifeExp <= 32)
aa <- df %>% filter(between(lifeExp, 29, 32))

#- observaciones de paises de Africa con lifeExp > 32
aa <- df %>% filter(lifeExp > 72 &  continent == "Africa")

#- observaciones de paises de Africa o Asia con lifeExp > 32
aa <- df %>% filter(lifeExp > 72 &  continent %in% c("Africa", "Asia") )
aa <- df %>% filter(lifeExp > 72 & (continent == "Africa" | continent == "Asia") )


##------------------------------------------------ Filtrar filas por POSICION: slice()
#- selecciona las observaciones de la decima a la quinceava
aa <- df %>% slice(c(10:15))

#- selecciona las observaciones de la 12 a 13 Y de la 44 a 46, Y las 4 últimas
aa <- df %>% slice( c(12:14, 44:46, n()-4:n()) ) #- AQUI hay un error, teneis q arreglarlo.
#- Pista: igual os ayuda crear una columna con el índice de rows
aa <- df %>% mutate(index = 1:n())
aa <- aa %>% slice( c(12:14, 44:46, (n()-4):n()) )


##---------------------------------------------------- Ordenar las filas: arrange()

#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp
aa <- df %>% arrange(lifeExp)

#- ordena las filas de MAYOR a menor según los valores de la v. lifeExp
aa <- df %>% arrange(desc(lifeExp))

#- ordenada las filas de MENOR a mayor según los valores de la v. lifeExp.
#- Si hay empates se resuelve con la variable "pop"
aa <- df %>% arrange(lifeExp, pop)



##--------------------------------------------------- Renombrar las variables: rename()

#- cambia los nombres de lifeExp y gdpPercap a life_exp y gdp_percap
df %>% rename(life_exp = lifeExp,  gdp_percap = gdpPercap)

#-(!!) la función names() es muy útil. Tb setNames() y set_names()
aa <- df
names(aa) <- names(aa) %>% toupper
names(aa) <- names(aa) %>% tolower
names(aa) <- c("var_01", "var_02", "var_03", "var_04", "var_05" , "var_06")
names(aa) <- paste0("Var_", 1:6)
names(aa) <- paste0("Lag_", formatC(1:6, width = 2, flag = "0"))


##--------------------------------------------------- seleccionar columnas: select()


#----- seleccionar variables  por NOMBRE

#- selecciono las variables year y lifeExp
aa <- df %>% select(year, lifeExp)
aa <- df %>% select(c(year, lifeExp))

#- selecciono todas las v. excepto "year"; osea, quitamos "year" del df
aa <- df %>% select(-year)

# quitamos year y lifeExp
aa <- df %>% select(-c(year, lifeExp))


#----- seleccionar variables  por POSICIÓN

#- seleccionamos las variables {1,2,3, 5}
aa <- df %>% select(1:3, 5)

#- quitamos las variables {1,2,3, 5}
aa <- df %>% select(- c(1:3, 5))


#----- mas posibilidades de select()

#- dejamos en aa solamente a las columnas "year" y "pop"; ADEMÁS, ahora, "pop" irá antes que "year"
aa <- df %>% select(pop, year)

#- "gdpPercap" que es la última columna pasa a ser la primera
aa <- df %>% select(gdpPercap, everything())

#(!!) otras 2 formas de hacer lo mismo: que la última columna pase a ser la primera
aa <- df %>% select( ncol(df), everything())
aa <- df %>% select( length(df), everything())



##--------------------------------------------------- CREAR nuevas variables: mutate()

#- Creamos la variable: GDP = pop*gdpperCap
aa <- df %>% mutate(GDP = pop*gdpPercap)



##--------------------------------------------------- RESUMIR: summarise()

#- retornará un único valor: la media global de la v. "lifeExp"
aa <- df %>% summarise(media = mean(lifeExp))

#- retornará un único valor: el número de filas
aa <- df %>% summarise(NN = n())  #- retornará un único valor: el número de filas

#- retornará un único valor: la desviación típica de la v. "lifeExp"
aa <- df %>% summarise(desviacion_tipica = sd(lifeExp))

#- retornará un único valor: el máximo de la variable "pop"
aa <- df %>% summarise(max(pop))

#- retornará 2 valores: la media y sd de la v. "lifeExp"
aa <- df %>% summarise(mean(lifeExp), sd(lifeExp))

#- retornará 2 valores: las medias de "lifeExp" y "gdpPercap"
aa <- df %>% summarise(mean(lifeExp), mean(gdpPercap))


#- aplicar summarise() a todas las columnas: sumarise_all()

#- media de cada una de las 6 variable. las 2 primeras son texto (en realidad son factores, lo puedes ver con str(df))
aa <- df %>% summarise_all(mean)
str(df)

#- media y sd de las 6 variable. las 2 primeras son factores (*** WTF !!!!)
aa <- df %>% summarise_all(funs(mean, sd) )



##--------------------------------------------------- agrupar/desagrupar el df en GRUPOS: group_by()

#- cogemos df y lo (des)agrupamos por grupos definidos por la variable "continent"; osea, habrá 5 grupos
#- después con summarise() calcularemos el nº de observaciones en cada continente o grupo; es decir, nos retornará un df con una fila por cada continente
aa <- df %>% group_by(continent) %>%  summarise(NN = n())
aa


#- cogemos df y lo agrupamos por "continent",
#- despues calculamos 2 cosas: el numero de observaciones o rows
#- y el número de países en cada continente (NN_countries)
aa <- df %>% group_by(continent) %>%
  summarize(NN = n(), NN_countries = n_distinct(country))
aa


#- cogemos df y lo agrupamos por "continent", después calculamos la media de "lifeExp"
aa <- df %>% group_by(continent) %>%
  summarize(mean(lifeExp))
aa


#- cogemos df y filtramos para quedarnos con las observaciones de 1952
#- despues lo agrupamos por "continent",
#- despues calculamos la media de "lifeExp"
aa <- df %>% filter(year == "1952") %>%
  group_by(continent) %>%
  summarize(mean(lifeExp))
aa


#- cogemos df y filtramos (cogemos) las observaciones de 1952 y 2007
#- agrupamos por "continent",
#- despues calculamos la media de "lifeExp" y de "gdpPercap"
aa <- df %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(mean(lifeExp), mean(gdpPercap))
aa



##------------------------------------------------------------------ summarise_at()


#- cogemos df y lo agrupamos por "continent" y "year", despues calculamos la media y mediana de "lifeExp" y de "gdpPercap"
aa <- df %>%
  filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarise_at(vars(lifeExp, gdpPercap), funs(mean, median)  )

aa



##------------------------------------------------------------------ summarise_if()


aa <- df %>%
  filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarise_if(is.numeric, funs(mean, median)  )

aa






#-------------------------------------------------------------------- CUESTIONES
#-------------------------------------------------------------------- CUESTIONES

# ¿En qué continente ha aumentado más la esperanza de vida?
# http://stat545.com/block010_dplyr-end-single-table.html


#- primer intento: se puede hacer de una vez, pero vamos a partir el código en 2 trozos
aa <- df %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(media_anyo = mean(lifeExp)) %>% ungroup()

aa1 <- aa %>% group_by(continent) %>%
  summarise(min_l = min(media_anyo), max_l = max(media_anyo)) %>%
  mutate(dif = max_l - min_l)


#- segundo intento: se puede hacer de una vez, pero vamos a partir el código en 2 trozos
aa <- df %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(media_anyo = mean(lifeExp)) %>% ungroup()

aa1 <- aa %>% group_by(continent) %>%
  arrange(year) %>%
  mutate(variacion_esperanza = media_anyo - lag(media_anyo))
aa1


#- en realidad este chunk no hace lo que dice el parrafo de arriba que hace !! ¿Qué es lo que realmente hace?
aa <- df %>%
  group_by(continent, year) %>%
  select(continent, year, lifeExp) %>%
  summarise(mean_life = mean(lifeExp)) %>%
  arrange(year) %>%
  mutate(incre_mean_life_0 = mean_life - first(mean_life)) %>%
  mutate(incre_mean_life_t = mean_life - lag(mean_life)) %>%
  arrange(continent)
aa




#- variación de lifeExp en Spain año a año (bueno lustro a lustro)
aa <- df %>%
  group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(lifeExp_gain_every_year = lifeExp - lag(lifeExp)) %>%
  filter(country == "Spain" )


#- ganancia acumulada
aa <- df %>%
  group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(lifeExp_gain_every_year = lifeExp - lag(lifeExp)) %>%
  #--- 2 filas nuevas
  mutate(lifeExp_gain_every_year2 = if_else(is.na(lifeExp_gain_every_year), 0, lifeExp_gain_every_year)) %>%
  mutate(lifeExp_gain_acumulado = cumsum(lifeExp_gain_every_year2)) %>%
  filter(country == "Spain")


#- ganancia acumulada (otra forma de hacer lo mismo)
aa <- df %>%
  group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(lifeExp_gain_acumulada = lifeExp - lifeExp[1])  %>%
  filter(country == "Spain")


#- Obtener, para cada periodo, los (3) países de Asia con MAYOR lifeExp.  (EJERCICIO... tic-tac tic-tac)



#- Obtener, para cada periodo, los países de Asia con mayor y menor lifeExp.
aa <- df %>%
  filter(continent == "Asia") %>%
  select(year, continent, country, lifeExp) %>%
  group_by(year) %>%
  filter(min_rank(desc(lifeExp)) < 2 | min_rank(lifeExp) < 2) %>%
  arrange(year)




# A ver si entendeis este ejemplo

# Una función auxiliar que es muy útil al utilizarla junto a mutate: case_when().
aa <- df %>%
  group_by(continent, year)  %>%
  mutate (media_lifeExp = mean(lifeExp)) %>%
  mutate (media_gdpPercap = mean(gdpPercap)) %>%
  mutate(GOOD_or_BAD = case_when(
    lifeExp > mean(lifeExp) & gdpPercap > mean(gdpPercap)  ~ "good",
    lifeExp < mean(lifeExp) & gdpPercap < mean(gdpPercap)  ~ "bad" ,
    lifeExp < mean(lifeExp) | gdpPercap < mean(gdpPercap)  ~ "medium"
  )) %>%
  filter(country == "Spain")





