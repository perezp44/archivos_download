#- ejemplo para practicar con tidyr (gather() y spread())
library(tidyr)
library(dplyr)

#----------------------------------------- DATA 1
data_1 <- data.frame(year = c("2014", "2015", "2016"),  Pedro = c(100, 500, 200), Carla = c(400, 600, 250), Maria = c(200, 700,900 ) )

#- en data_1 los individuos están en columnas, así que vamos a "arreglarlos" con la f. t()

#------------------------ no funciona 
aa <- t(data_1)
aa <- as.data.frame(t(data_1))

#----------------------  con R-base
aa <- t(data_1[,2:ncol(data_1)])  #- trasponemos los datos (pero no la primera columna)
colnames(aa) <- data_1[,1]        #- ponemos como colnames los valores de la primera columna
aa <- as.data.frame(aa)           #- convertimos a df     

#---------------------- con tidyr (3 formas alternativas de hacerlo)
aa <- data_1 %>% gather(Nombre, Salario, 2:ncol(data_1))  %>%  spread(year, Salario) 
aa <- data_1 %>% gather(Nombre, Salario, 2:4)  %>%  spread(year, Salario)
aa <- data_1 %>% gather(Nombre, Salario, Pedro:Maria)  %>%  spread(year, Salario)


rm(aa, data_1)




#------------------------------------------- DATA 2
data_2 <- data.frame( names = c("Pedro", "Carla", "María"), W_2014 = c(100, 400, 200), W_2015 = c(500, 600, 700),  W_2016 = c(200, 250, 900))

#- data_2 está en formato ancho (wide)
data_wide <- data_2


#- la funcióm gather() transforma los datos de formato ancho(wide) a formato largo(long)
data_long <- data_wide %>% gather(periodo, salario, 2:4)

data_long <- data_long %>% mutate(periodo = gsub("W_", "" , periodo))

#- spread() convierte un df de long a wide
data_wide2 <- data_long %>% spread(periodo, salario)



#------------------- separate() y unite()
df <- data.frame(names = c("Pedro Navaja", "Bob Dylan", "Cid Campeador"), year  = c(1978, 1941, 1048) )

# separate()
df_a <- df %>% separate(names, c("Nombre", "Apellido"), sep = " ")


# unite()
df_b <- df_a %>% unite(Nombre_y_Apellido, Apellido:Nombre, sep = ", ")



