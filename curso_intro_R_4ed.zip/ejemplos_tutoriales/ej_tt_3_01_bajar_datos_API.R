#- cargar datos de varias APIs
#install.packages("eurostat") #- para instalar la 3.2.1
library("tidyverse")
#------------------------------------------   EUROSTAT
library("eurostat")


#------------------ podemos buscar un  "tema" con la f. search_eurostat()
aa <- search_eurostat("employment", type = "all")

#------------------ elegimos una tabla de Eurostat
my_table <- "hlth_silc_17"          #- elegimos una tabla; por ejemplo "hlth_silc_17": "Healthy life expectancy based on self-perceived health"
label_eurostat_tables(my_table)     #- da informacion sobre la Base de datos q estas buscando

#------------------ descargamos los datos con get_eurostat()
df <- get_eurostat(my_table, time_format = 'raw', keepFlags = T )       #- bajamos los datos de una tabla
df_l <- label_eurostat(df)        #- pone labels: Spain en lugar de su código (mas legible,menos fácil de programar)

#------------------ los arreglamos un poco
#devtools::install_github("perezp44/personal.pjp")
library("personal.pjp")
aa <- val_unicos_df_pjp(df)       #- ver los valores unicos de cada columna
aa <- val_unicos_df_pjp(df_l)     #- ver los valores unicos de cada columna
df <- label_eurostat(df, code = c("geo", "unit", "indic_he"))


#- selecciono datos de 2016, Females, y HE_50 y despues hago un cut de "values"
df_x <- df %>% filter(time == "2016") %>%  filter(sex == "Females") %>% filter(indic_he_code == "HE_50") %>%
  mutate(cat = cut_to_classes(values, n = 7, decimals = 1))

#- la verion de eurostat anterior se hacia así:
#mapdata <- merge_eurostat_geodata(df_x, resolution = "20", geocolumn = "geo_code") #- fusiono con geo data (DEPRECATED)
# library("ggplot2")
# ggplot(mapdata, aes(x = long, y = lat, group = group))+
#   geom_polygon(aes(fill = cat), color = "black", size = .1)+
#   scale_fill_brewer(palette = "RdYlBu") +
#   labs(title = "Healthy life expectancy, 2016",
#        subtitle = "Health expectancy in years at 50",
#        fill = "Healthy life expectancy",
#        caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
#   coord_map(xlim = c(-12,44), ylim = c(35,67))


#- con la nueva version de eurostat se hace así:
geometrias <- get_eurostat_geospatial(resolution = "20", nuts_level = "0") #- ahora se bajan las geometrias y tienes que unirla tu con dplyr (Hay un Pb de encoding)
mapdata <- inner_join(df_x, geometrias, by = c("geo_code" = "geo"))

ggplot(mapdata) +
  geom_sf(aes(fill = cat), color = "black", size = .1) +
  scale_fill_brewer(palette = "RdYlBu") +
  labs(title = "Healthy life expectancy, 2016",
       subtitle = "Health expectancy in years at 50",
       fill = "Healthy life expectancy",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12,44), ylim = c(35,67)) #- ha cambiado








#------------------------------------------   INE
library("tidyverse")
library("personal.pjp")
library("pxR")              #- para trabajar con datos PC-Axis


file_name <- "http://www.ine.es/jaxiT3/files/t/es/px/4189.px?nocab=1"
df <- read.px(file_name) %>% as.data.frame() %>% as.tbl()   #- no funciona en 3.5 x $
aa <- val_unicos_df_pjp(df)     #- ver los valores unicos de cada columna





#------------------------------------------   Banco MUNDIAL
#install.packages("WDI")
library("WDI")

#---- buscamos datos relacionados con GDP
aa <- WDIsearch('gdp')
aa <- WDIsearch('gdp.*capita.*constant')

#---- descargamos "NY.GDP.PCAP.KD":  GDP per capita (constant 2010 US$)
df <- WDI(indicator = "NY.GDP.PCAP.KD")

#---- podemos filtrar la querry
df <- WDI(indicator = "NY.GDP.PCAP.KD", country = c('MX','CA','US'), start = 1960, end = 2017)

#------------------------------------------   Banco MUNDIAL
#install.packages("wbstats")
library("wbstats")

#-------  lista de indicadores disponibles
aa <- wb_cachelist

#---- buscamos datos relacionados con GDP
aa <- wbsearch(pattern = "gdp")
aa <- wbsearch('gdp.*capita.*constant')

#---- descargamos "NY.GDP.PCAP.KD":  GDP per capita (constant 2010 US$)
df <- wb(indicator = "NY.GDP.PCAP.KD")

#---- podemos filtrar la querry
df <- wb(indicator = "NY.GDP.PCAP.KD", country = c('MX','CA','US'), startdate = 2000, enddate = 2017)



#------------------------------------------   CROSS REF
#install.packages("rcrossref")
library("rcrossref")

#----- con cr_cn() podemos ver como se cita un determinado articulo en un determinado formato, por ejemplo "apa"
my_doi <- "10.1111/j.1467-6486.2012.01072.x"
cr_cn(dois = my_doi, format = "text", style = "apa")

cr_cn(dois = my_doi, format = "bibtex", style = "apa", locale = "en-US", raw = FALSE, progress = "none")

#------ con cr_citation_count() puedes ver el numero de citas de un artículo/DOI
aa <- cr_citation_count(doi = my_doi)

#------ con cr_abstract()
aa <- cr_abstract(doi = "10.1109/TASC.2010.2088091")

#------ con cr_journals() vemos journals
aa <- cr_journals(query = "economics", limit = 100) %>% .$data %>% as.tibble()

#------ mucha informacion del articulo
aa <- cr_works(dois = my_doi) %>% .$data %>% as.tibble()



#---------------------------------------- Web scrapping de una tabla de la Wikipedia
library("rvest")
library("tidyverse")
content <- read_html("https://es.wikipedia.org/wiki/Anexo:Municipios_de_la_provincia_de_Teruel")

body_table <- content %>% html_nodes('body')  %>%
                    html_nodes('table') %>%
                    html_table(dec = ",")

Teruel <- body_table[[1]]

names(Teruel) <- c("Nombre", "Extension", "Poblacion", "Densidad", "Comarca", "Partido_judicial", "Altitud")

library(stringr)
Teruel <- Teruel %>% map(str_trim) %>% as_tibble() #- quita caracteres al final
Teruel <- Teruel %>% mutate(Altitud = str_replace_all(Altitud,"[[:punct:]]", ""))
Teruel <- Teruel %>% mutate(Altitud = as.double(Altitud)) %>% arrange(desc(Altitud))

