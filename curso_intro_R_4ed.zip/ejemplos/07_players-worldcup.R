#- https://rviews.rstudio.com/2018/06/14/player-data-for-the-2018-fifa-world-cup/

# install.packages("tidyverse")
# install.packages("lubridate")
# install.packages("cowplot")
# install.packages("tabulizer")
# install.packages("rvest")
# install.packages("ggrough")


library(tidyverse)
library(stringr)
library(lubridate)
library(cowplot)
library(tabulizer)

#- extract data from an oficial pdf publication from the FIFA
url <- "https://github.com/davidkane9/wc18/raw/master/fifa_player_list_1.pdf"   #- url of the pdf
#out <- extract_tables(url, output = "data.frame")                              #- 32 teams
out <- extract_tables(url, output = "data.frame", encoding = "UTF-8")           #- solving problem with encoding


#- joining the 32 elements of the list
pdf_data <- bind_rows(out) %>%  as_tibble()

# Make the variable names more tidy-like.
pdf_data <- pdf_data %>% rename(team = Team,
                                number = X.,
                                position = Pos.,
                                name = FIFA.Popular.Name,
                                birth_date = Birth.Date,
                                shirt_name = Shirt.Name,
                                club = Club,
                                height = Height,
                                weight = Weight)

# Country names are contentious issues. I modify two names because I will later need to merge this tibble with data from Wikipedia, which uses different names.
# Arregla los nombres de los paises xq luego fusionara con otra tabla sacada de Wikipedia
pdf_data <- pdf_data %>%  mutate(team = case_when(
                                 team == "Korea Republic" ~ "South Korea",
                                 team == "IR Iran" ~ "Iran",
                                 TRUE ~ team))

# league and club should be separate variables. WE can separete it with tidyr::separate()
#  but David Kane (the post author) separates league & club with stringr::str_sub()
pdf_data <- pdf_data %>%  mutate(league = str_sub(club, -4, -2) ,
                                 club   = str_sub(club, end = -7) )

# We also want birth_date to be a date (pkg lubridate)
pdf_data <- pdf_data %>% mutate(birth_date = dmy(birth_date))

#- creatint the age of the players
pdf_data <- pdf_data %>% mutate(age = interval(birth_date, "2018-06-14") / years(1))
pdf_data <- pdf_data %>% mutate(my_age = interval(birth_date, Sys.Date()) / years(1))  #- To be more "exact" with the age of the player


#- David Kane makes some "unit test" to be sure that things are going OK
stopifnot(length(unique(pdf_data$team)) == 32)      # There are 32 teams.)
stopifnot(all(range(table(pdf_data$team)) == 23))   # Each team has 23 players.
stopifnot(pdf_data %>%
            filter(position == "GK") %>%
            group_by(team) %>%
            tally() %>%
            filter(n != 3) %>%
            nrow() == 0)                     # All teams have 3 goal keepers.
stopifnot(all(pdf_data$position %in%
                c("GK", "DF", "MF", "FW")))  # All players assigned to 1 of 4 positions.
head(pdf_data)



#- dowloading more details about the players from wikipedia
library(rvest)
html <- read_html("https://en.wikipedia.org/wiki/2018_FIFA_World_Cup_squads")

# Once we have read in all the html, we need to identify the location of the data we want.
# The rvest vignette provides guidance, but the key trick is the use of SelectorGadget to find the correct CSS node.

# First, we need the country and the shirt number of each player so that we can # merge this data with that from the PDF.

country <- html_nodes(html, ".mw-headline") %>%
  html_text() %>%
  as_tibble() %>%
  filter(! str_detect(value, "Group")) %>%
  slice(1:32)

number <- html_nodes(html, ".plainrowheaders td:nth-child(1)") %>%
  html_text()

# We don't need the name of each player but I like to grab it, both because I
# prefer the Wikipedia formatting and to use this as a cross-check on the
# accuracy of our country/number merge.

name <- html_nodes(html, "th a") %>%
  html_text() %>%
  as_tibble() %>%
  filter(! str_detect(value, "^captain$")) %>%
  slice(1:736)

# cap is the variable we care about, but Wikipedia page also includes the number
# of goals that each player has scored for the national team. Try adding that
# information on your own.

caps <- html_nodes(html, ".plainrowheaders td:nth-child(5)") %>% html_text()
goles <- html_nodes(html, ".plainrowheaders td:nth-child(6)") %>% html_text()  #- we take also the "goles"


# Create a tibble. Note that we are relying on all the vectors being in the correct order (puffff yas!!)

wiki_data <- tibble(
  number = as.numeric(number),
  name = name$value,
  team = rep(country$value, each = 23),
  caps = as.numeric(caps),
  goles = as.numeric(goles))

# I prefer the name from Wikipedia. Exercise for the reader: How might we use
# name (from Wikipedia) and shirt_name (from the PDF) to confirm that we have
# lined up the data correctly?

x <- left_join(select(pdf_data, -name), wiki_data, by = c("team", "number"))  #- it seems all correct, 736 jurgol-players

#- We can start the data exploration -----------------------------
#- We can start the data exploration -----------------------------

ggplot(x, aes(x = height, y = weight, color = position)) + geom_point()


my_plot <- ggplot(x, aes(x = position, y = height)) +
  geom_boxplot(outlier.colour = "hotpink") +
  geom_jitter(position = position_jitter(width = 0.1, height = 0), alpha = 1/4) +
  labs(title = "Height vs position",
       subtitle = "Russia World Cup",
       x = "Height", y = "Position")



my_plot <- ggplot(x, aes(x = reorder(position, height, FUN = mean) ,    y = height)) +
  geom_boxplot(outlier.colour = "hotpink") +
  geom_jitter(position = position_jitter(width = 0.1, height = 0), alpha = 1/4) +
  labs(title = "Height vs position",
       subtitle = "Russia World Cup",
       x = "Height", y = "Position")

my_plot

#- Height by team ---------------------------------------------------------------------
my_plot <- ggplot(x, aes(x = reorder(team, height, FUN = mean) ,    y = height)) +
  geom_boxplot() +
  geom_jitter(position = position_jitter(width = 0.1, height = 0), alpha = 1/4) +
  labs(title = "Height by team",
       subtitle = "Russia World Cup",
       x = "Height", y = "Position") + coord_flip()




aa <- x %>% group_by(team) %>% summarise_at( vars(height, weight), funs(mean)) %>%
             arrange(desc(height))



p <- ggplot(aa, aes(height, weight)) + geom_point() + geom_smooth(method = "lm", colour = "red")



p <- p + geom_text(aes(label = team), hjust = -0.05, vjust = -0.05)





#- Davd calculates the "Team quality", see their post:  https://rviews.rstudio.com/2018/06/14/player-data-for-the-2018-fifa-world-cup/
x %>% group_by(league) %>% tally() %>% arrange(desc(n))

x %>%
  group_by(team) %>%
  summarise(elite = mean(league %in% c("ENG", "ESP", "GER", "ITA", "FRA"))) %>%
  arrange(desc(elite)) %>%
  slice(c(1:8, 29:32))


#- didn't work for this type of graph
#devtools::install_github("xvrdm/ggrough")
library("ggrough")

options <- list(
  Background=list(roughness=8),
  GeomCol=list(fill_style = "zigzag", angle_noise=0.5, fill_weight=2))
get_rough_chart(p, options)
get_rough_chart(p)
