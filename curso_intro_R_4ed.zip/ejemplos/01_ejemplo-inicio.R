#- ejemplo simple para familiarizarse un poco con el entorno de RStudio y la sintaxis de R
#- cargaremos unos datos de internet y haremos algunos gráficos

#install.packages("tidyverse")
#install.packages("ggthemes")

#- cargamos paquetes en memoria
library(tidyverse)
library(ggthemes)

#- cargamos 2 conjuntos de datos -----
nivel_CO2   <- read.table("ftp://aftp.cmdl.noaa.gov/products/trends/co2/co2_annmean_mlo.txt")
temperatura <- read.table("https://go.nasa.gov/2r8ryH1", skip = 5)

#- arreglamos un poco los datos -----
temperatura <- temperatura %>% rename(celsius = V2)                #- cambiamos el nombre de la v. V2 a "celsius"
temperatura <- temperatura %>% select(-V3)                         #- eliminamos V3 del df "temperatura"
temperatura <- temperatura %>% mutate(celsius_100 = celsius*100)   #- creamos la variable "celsius_100" como celsius*100

#- fusionamos las 2 tablas (dataframes) de datos -----
datos <- inner_join(nivel_CO2, temperatura, by = "V1")

# hacemos gráficos con R-base -----
plot(datos$V2, datos$celsius)

#- hacemos gráficos con el pkg ggplot2 -----
ggplot(datos, aes(V2, celsius)) + geom_point()



#- hacemos más gráficos con ggplot2 -----
ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth()

ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth() + geom_smooth(method = "lm", colour = "red")

ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth(method = "lm") +
  xlab("CO2") + ylab("Temperatura") + theme_dark()

ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth(method = "lm") +
  labs(title = "Temperatura vs. CO2",
       subtitle = "1959-2018",
       caption = "https://go.nasa.gov/2r8ryH1",
       x = "CO2")




#- veamos mas themes() -----
# https://yutannihilation.github.io/allYourFigureAreBelongToUs/ggthemes/
# http://www.ggplot2-exts.org/gallery/         #- pegadle un vistazo a esta gallery


my_plot <- ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth(method = "lm") +
              labs(title = "Temperatura vs. CO2",
                   subtitle = "1959-2018",
                   caption = "https://go.nasa.gov/2r8ryH1",
                   x = "CO2")


my_plot  + theme_economist()

my_plot + theme_stata()

my_plot + theme_fivethirtyeight()

my_plot + theme_excel()

#- TAREA: poner la linea de regresión en "my_plot" de color verde [pista: colour = "green"]

#- TAREA: ¿hacemos el gráfico interactivo? [pista: plotly::ggplotly()](https://plot.ly/ggplot2/)


interactive_plot <- plotly::ggplotly(my_plot)

#- planteamos y estimamos un modelo lineal ---
lm(formula = celsius ~ V2, data = datos)

my_model <- lm(celsius ~ V2, datos)
summary(my_model)


#- para hacer tablas hay multitud de paquetes. Por ejemplo
# install.packages("jtools")
library(jtools)
jtools::summ(my_model) #- https://cran.r-project.org/web/packages/jtools/vignettes/summ.html
summ(my_model, confint = TRUE, digits = 3) #- con intervalo de confianza




#--------------------------------------------------------------------------------------------
#- un theeme() para politólogos: https://github.com/erocoar/ggpol
#- Además la BBC ... ¿Cómo hace sus gráficos? https://medium.com/bbc-visual-and-data-journalism/how-the-bbc-visual-and-data-journalism-team-works-with-graphics-in-r-ed0b35693535


#devtools::install_github('erocoar/ggpol')
library(ggpol)

df_parlam <- tibble(
  parties = factor(c("CDU", "CSU", "AfD", "FDP", "SPD", "Linke", "Gruene", "Fraktionslos"),
            levels = c("CDU", "CSU", "AfD", "FDP", "SPD", "Linke", "Gruene", "Fraktionslos")),
  seats   = c(200, 46, 92, 80, 153, 69, 67, 2),
  colors  = c("black", "blue", "lightblue", "yellow", "red","purple", "green", "grey")   )


ggplot(df_parlam) +
  geom_parliament(aes(seats = seats, fill = parties), color = "black") +
  scale_fill_manual(values = df_parlam$colors, labels = df_parlam$parties) +
  coord_fixed() +
  theme_void()



# TAREA: ¿qué pasará si en lugar de theme_void() usásemos otro theme()?
# TAREA: ¿le ponemos un titulo y substitulo al gráfico? Pista: labs(title = "Parlamento alemán", subtitle = "2018", caption = "R mola")


#- Vamos a hacer el gráfico interactivo
library(plotly)
p <- ggplotly(my_plot)

