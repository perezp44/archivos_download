#- el trabajo para casa del curso de intro a R (4ed)

library(tidyverse)
library(sf)
#library(LAU2boundaries4spain) # devtools::install_github("perezp44/LAU2boundaries4spain", force = TRUE)
library(spanishRpoblacion)

#- cargamos datos de lindes provinciales y municipales ------------------------------------------
Provincias <- Provincias   # cargamos en memoria el fichero de lindes provinciales
Provincias <- load("./datos/Provincias.rda")   # cargamos en memoria el fichero de lindes provinciales
str(Provincias)
# plot(Provincias, max.plot = 1)                  #- las graficamos
#Municipios_16 <- municipios_2016                  # cargamos en memoria el fichero de lindes provinciales: 8.125 municipios + 84 condominios
municipios_2016 <- load("./datos/municipios_2016.rda")                    # cargamos en memoria el fichero de lindes provinciales: 8.125 municipios + 84 condominios
Municipios_16   <- municipios_2016 #- 
str(Municipios_16)
# plot(Municipios_16, max.plot = 1)               #- las graficamos



#- cargamos datos de poblacion del Padron --------------------------------------------------------
pob <- INE_padron_muni_96_17  #- datos de poblacion del Padron


#- vamos a marcar con 1 los municipios q en 2016 tenían mas mujeres que hombres -------------------
pob_2016 <- pob %>% filter


## El resto lo teneis que hacer vosotros !!
