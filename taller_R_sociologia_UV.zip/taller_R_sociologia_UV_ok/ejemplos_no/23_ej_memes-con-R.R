#- package para hacer memes: https://github.com/GuangchuangYu/meme/
# install.packages("meme")

library(meme)
vignette("meme", package = "meme")

u <- system.file("success.jpg", package = "meme")
meme(u, "SÍ se puede!!!", "aprended R", size = 2.0, color = "purple")
