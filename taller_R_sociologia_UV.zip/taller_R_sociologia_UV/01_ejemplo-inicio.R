#- ejemplo simple para familiarizarse un poco con la sintaxis de R
#- cargaremos datos de internet y haremos algunos gráficos

#install.packages("tidyverse")
#install.packages("ggthemes")

#- cargamos paquetes en memoria
library(tidyverse)
library(ggthemes)

# cargamos datos
nivel_CO2   <- read.table("ftp://aftp.cmdl.noaa.gov/products/trends/co2/co2_annmean_mlo.txt")
temperatura <- read.table("https://go.nasa.gov/2r8ryH1", skip = 5)

# arreglamos datos
temperatura <- temperatura %>% rename(celsius = V2)                #- cambiamos el nombre de la v. V2 a "celsius"
temperatura <- temperatura %>% select(-V3)                         #- eliminamos V3 del df "temperatura"
temperatura <- temperatura %>% mutate(celsius_100 = celsius*100)   #- creamos la variable "celsius_100" como celsius*100

# fusionamos datos-----
datos <- inner_join(nivel_CO2, temperatura, by = "V1")

# hacemos gráficos -----
plot(datos$V2, datos$celsius)     #- con base-R


#- gráficos (pkg: ggplot2) -----
ggplot(datos, aes(V2, celsius)) + geom_point()

ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth()

ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth() + geom_smooth(method = "lm", colour = "red")

ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth(method = "lm") +
  xlab("CO2") + ylab("Temperatura") + theme_dark()

ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth(method = "lm") +
  labs(title = "Temperatura vs. CO2",
       subtitle = "1959-2018",
       caption = "https://go.nasa.gov/2r8ryH1",
       x = "CO2")




#- mas themes -----
# https://yutannihilation.github.io/allYourFigureAreBelongToUs/ggthemes/
# http://www.ggplot2-exts.org/gallery/


my_plot <- ggplot(datos, aes(V2, celsius)) + geom_point() + geom_smooth(method = "lm") +
              labs(title = "Temperatura vs. CO2",
                   subtitle = "1959-2018",
                   caption = "https://go.nasa.gov/2r8ryH1",
                   x = "CO2")


my_plot  + theme_economist()

my_plot + theme_stata()

my_plot + theme_fivethirtyeight()

my_plot + theme_excel()




#- TAREA: poner la linea de regresión en "my_plot" de color verde [pista: colour = "green"]



#-----------------------------------------------------------------------------------------------------------
#- un tema que igual os gusta, aunque quizás es más para politólogos: https://github.com/erocoar/ggpol
#- Además la BBC ... ¿Cómo hace sus gráficos? https://medium.com/bbc-visual-and-data-journalism/how-the-bbc-visual-and-data-journalism-team-works-with-graphics-in-r-ed0b35693535


#devtools::install_github('erocoar/ggpol')


library(ggpol)

d_parlam <- tibble(
  parties = factor(c("CDU", "CSU", "AfD", "FDP", "SPD", "Linke", "Gruene", "Fraktionslos"),
            levels = c("CDU", "CSU", "AfD", "FDP", "SPD", "Linke", "Gruene", "Fraktionslos")),
  seats   = c(200, 46, 92, 80, 153, 69, 67, 2),
  colors  = c("black", "blue", "lightblue", "yellow", "red","purple", "green", "grey")   )


ggplot(d_parlam) +
  geom_parliament(aes(seats = seats, fill = parties), color = "black") +
  scale_fill_manual(values = d_parlam$colors, labels = d_parlam$parties) +
  coord_fixed() +
  theme_void()

# TAREA: ¿qué pasara si en lugar de theme_void() usasemos otro theme?
