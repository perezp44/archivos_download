#- http://graphtweets.john-coene.com/index.html
#- devtools::install_github("JohnCoene/graphTweets") # dev version
library(rtweet)
library(graphTweets)

#:- NUEVO: https://github.com/schochastics/graphlayouts
# @schochastics: Good news everyone! The graphlayouts #rstats package is now available on CRAN. Best use in connection with #ggraph. Give it a spin a let me know if u find any bugs. https://twitter.com/schochastics/status/1115164318843252737/photo/1


# 1'000 tweets on #rstats, excluding retweets
tweets <- search_tweets("#sociologia", n = 500, include_rts = FALSE)
#rio::export(tweets, "./datos/tweets.rds")
tweets <- rio::import("./datos/tweets.rds")


#-
tweets %>%
  gt_edges(text, screen_name, status_id) %>%
  gt_graph() -> graph

class(graph)

plot(graph)


#-
tweets %>%
  gt_edges(text, screen_name, status_id) %>%
  gt_collect() -> edges

names(edges)
tweets %>%
  gt_edges(text, screen_name, status_id) %>%
  gt_nodes() %>%
  gt_collect() -> graph

lapply(graph, nrow) # number of edges and nodes
lapply(graph, names) # names of data.frames returned


tweets %>%
  gt_edges(text, screen_name, status_id) %>%
  gt_nodes(meta = TRUE) %>%
  gt_collect() -> graph



library(igraph)

tweets %>%
  gt_edges(text, screen_name, status_id) %>%
  gt_graph() -> g

# communities
wc <- walktrap.community(g)
V(g)$color <- membership(wc)

# plot
# tons of arrguments because defaults are awful
plot(g,
     layout = igraph::layout.fruchterman.reingold(g),
     vertex.color = V(g)$color,
     vertex.label.family = "sans",
     vertex.label.color = hsv(h = 0, s = 0, v = 0, alpha = 0.0),
     vertex.size = igraph::degree(g),
     edge.arrow.size = 0.2,
     edge.arrow.width = 0.3, edge.width = 1,
     edge.color = hsv(h = 1, s = .59, v = .91, alpha = 0.7),
     vertex.frame.color="#fcfcfc")

#- https://perrystephenson.me/2018/09/29/the-r-twitter-network/
