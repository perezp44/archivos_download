# https://www.cultureofinsight.com/blog/2018/01/25/2018-01-25-visualising-twitter-follower-overlap/
#- https://cran.r-project.org/web/packages/rtweet/index.html

library(rtweet)
library(tidyverse)
library(UpSetR)

#- get a list of twitter accounts you want to compare
names_politicos <- c("sanchezcastejon", "Pablo_Iglesias_", "Albert_Rivera", "pablocasado_")
politicos <- lookup_users(names_politicos)
zz_ver_politicos <- politicos %>% select(user_id, screen_name, created_at, text, favorite_count, retweet_count, hashtags)

rm(zz_ver_politicos)

# queria bajarme los datos de las cuentas de sus seguidores, PERO, alguno de ellos tiene mas de 2 millones de followers!!!
#followers <- map_df(politicos, ~ get_followers(.x, n = 20000, retryonratelimit = TRUE) %>% mutate(account = .x))


#-  así que cambio de enfoquee y en lugar de buscar a sus seguidores voy a bajar la información para
#- ¿qué personas o cuentas de twitter siguén nuestros políticos? Para que no falle el dia de la expo los he guardado en ./datos
# friends <- map_df(politicos, ~ get_friends(.x, n = 20000, retryonratelimit = TRUE) %>% mutate(account = .x)) #------ BUSCA
# write_rds(friends, "./datos/friends.rds")
friends <- read_rds("./datos/friends.rds")



#- vamos  abajarnos la informacion de los friends de nuestros políticos:
# friends_data <- lookup_users(friends$user_id)   #---- BUSCA
#write_rds(friends_data, "./datos/friends_data.rds")
friends_data <- read_rds("./datos/friends_data.rds")

#write_rds(followers, "./datos/followers.rds")
#followers <- readRDS("./datos/followers.rds")


#- vamos a hacer un gráfico útil con el pkg UpSetR -----------------------------------------------------
aRdent_followers <- unique(friends$user_id) #- get a de-duplicated list of all followers

# for each follower, get a binary indicator of whether they follow each tweeter or not and bind to one dataframe
binaries <- names_politicos %>%
  map_dfc(~ ifelse(aRdent_followers %in% filter(friends, account == .x)$user_id, 1, 0) %>%
            as.data.frame) # UpSetR doesn't like tibbles

names(binaries) <- names_politicos   #- # set column names

# plot the sets with UpSetR
upset(binaries, nsets = 7, main.bar.color = "SteelBlue", sets.bar.color = "DarkCyan",
      sets.x.label = "Gente a la que siguen nuestros políticos", text.scale = c(rep(1.4, 5), 1), order.by = "freq")



rm(binaries, aRdent_followers)  #- borro objetos

#--- Quienes son está gente a la que nuetros políticos siguen en twitter?? ------------------------------------------------------------
df_1 <- friends_data %>% select(user_id, screen_name, name, description, protected, followers_count, friends_count, profile_image_url, status_url)


#- Cómo hacemos para buscar a la gente que es seguida por los 4 políticos??
df_2 <- friends %>% group_by(user_id) %>% count() %>% filter(n == 4) %>% arrange(desc(n))
df_influyente <- df_1 %>% filter(user_id %in% df_2$user_id)

rm(df_1, df_2, df_influyente, politicos)

#- lo hacemos de otra forma
friends_x <- friends %>% mutate(nnn = 1) %>% select(- user) %>%
                        spread(account, nnn) %>%
                        replace(is.na(.), 0) %>%
                        mutate(qq = sanchezcastejon + Pablo_Iglesias_ + Albert_Rivera + pablocasado_)


#- busquemos a la interseccion entre Pablo y Pedro
pablo_y_pedro <- friends_x %>% filter(Pablo_Iglesias_ == 1 & sanchezcastejon == 1 )  #- pero salen 161 ??? [Pista: Albert_Rivera == 0 & pablocasado_ == 0]


df_PyP <- friends_data %>% filter( user_id %in% pablo_y_pedro$user_id) %>% select(user_id, screen_name, name, description, protected, followers_count, friends_count, profile_image_url, status_url)



#- pablo_y_pedro <- friends_x %>% filter(Pablo_Iglesias_ == 1 & sanchezcastejon == 1 & Albert_Rivera == 0 & pablocasado_ == 0)  #- pero salen 161 ??? [Pista: Albert_Rivera == 0 & pablocasado_ == 0]


#- @Proscojoncio: Bueno, pues aquí 20 cuentas creadas en Marzo con avatares creados mediante FaceApp o imágenes de Internet, que casualmente están gestionadas con TweetDeck y escriben para mostrar apoyo a @pablocasado_, sabotear el hashtag #HazQuePase y/o difundir el hashtag #SanchezMentiroso. https://twitter.com/Proscojoncio/status/1113400589038256129/photo/1
