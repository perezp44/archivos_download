#- 5 nuevos casos chulos:

#- “(Trying) to get to the top of R-bloggers emails”: https://embracingtherandom.com/r/web-scraping/email/apis/trying-to-get-to-the-top-of-r-bloggers-emails/



#- Explore your Researcher Degrees of Freedom https://www.r-bloggers.com/explore-your-researcher-degrees-of-freedom/


#- https://joachim-gassen.github.io/2018/12/interactive-panel-eda-with-3-lines-of-code/
aa <- iris
install.packages("ExPanDaR")
library(ExPanDaR)
wb <- read.csv("https://joachim-gassen.github.io/data/wb_condensed.csv")
ExPanD(wb, cs_id = "country", ts_id = "year")
ExPanD(iris, cs_id = "Species", ts_id = "Sepal.Length")




#- https://observablehq.com/@harrystevens/introducing-d3-regression



#- parece que se han puesto de moda los animated race barcharts:
#- @emilykuehler: Made a bar chart race using #gganimate for #TidyTuesday, inspired by @jburnmurdoch. code available here: https://github.com/emilykuehler/tidytuesday/blob/master/grand-slam-tennis/tennis.R https://twitter.com/emilykuehler/status/1115525762927419392/photo/1
#- How to Create a Bar Chart Race in R – Mapping United States City Population 1790-2010 https://www.r-bloggers.com/how-to-create-a-bar-chart-race-in-r-mapping-united-states-city-population-1790-2010/
#- https://towardsdatascience.com/create-animated-bar-charts-using-r-31d09e5841da
#- How to build Animated Bar Plots using R https://www.r-bloggers.com/how-to-build-animated-bar-plots-using-r/



#- https://github.com/rCarto/popcircle

#- Garmonbozia: Using R to look at Garmin CSV data https://www.r-bloggers.com/garmonbozia-using-r-to-look-at-garmin-csv-data/


#- - @joedgallagher: New R package, 'soccermatics' ⚽📦 pretty #dataviz of #football player x,y-data using ggplot https://github.com/JoGall/soccermatics … #rstats @soccermatics https://twitter.com/joedgallagher/status/913378028201406471/photo/1






#- links para aprender:
#---------------------------------------------------:

#- @lingtax: @siminevazire @dalejbarr I'd recommend flipping through R4DS (https://r4ds.had.co.nz/introduction.html) and then having a go at #TidyTuesday (https://github.com/rfordatascience/tidytuesday). It's a good, low-stakes way of learning by doing.  https://thomasmock.netlify.com/post/tidytuesday-a-weekly-social-data-project-in-r/   Os recomiendo las de David Robinson: https://www.youtube.com/watch?v=YWUCUfEeNJI

#- Otro buen recurso son los webinars de RStudio: https://resources.rstudio.com/webinars/what-every-data-scientist-should-know-about-education-greg-wilson




#- R4DS: https://r4ds.had.co.nz/     tb está en castellano: https://es.r4ds.hadley.nz/

#- soluciones R4Ds: https://jrnold.github.io/r4ds-exercise-solutions/

#- Danielle Navarro: https://learningstatisticswithr-bookdown.netlify.com/

#- un curso de Sociologia con R: https://github.com/cbail/Computational-Sociology




