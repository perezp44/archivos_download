
install.packages("devtools")
install.packages("tidyverse")
install.packages("rio")
install.packages("ggthemes")
install.packages("eurostat")
install.packages("gganimate")
install.packages("gapminder")
install.packages("rtweet")
install.packages("UpSetR")
install.packages("essurvey")
install.packages("ggpol")
install.packages("SPARQL")
install.packages("wordcloud2")
install.packages("gifski")
install.packages("snakecase")
install.packages("corrplot")
install.packages("meme")
devtools::install_github("hadley/emo")
devtools::install_github("perezp44/pjp.funs", force = TRUE)
devtools::install_github("JohnCoene/graphTweets")



install.packages("png")


#- https://github.com/perezp44/archivos_download/raw/master/taller_R_sociologia_UV.zip
#- voy a intentar que se descargue el repo automáticamente
#download.file(url = "https://github.com/perezp44/archivos_download/raw/master/taller_R_sociologia_UV.zip", destfile = "./taller_R_sociologia_UV.zip")

# unzip the .zip file
#unzip(zipfile = "./taller_R_sociologia_UV.zip")



#- A lo mejor usamos este etherpad: https://etherpad.wikimedia.org/p/curso_intro_R
#- A lo mejor usamos RStudio Cloud: https://rstudio.cloud/
#- Concretamente este proyecto: https://rstudio.cloud/project/302220


