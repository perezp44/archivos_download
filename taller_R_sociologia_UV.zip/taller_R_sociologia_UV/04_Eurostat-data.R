#--- Objective: Obtain data from Eurostat --------------------------------------------------------
# install.packages("tidyverse")
# install.packages("eurostat") #- EUROSTAT pkg

#------------------------------------------   loading  the packages
library("tidyverse")
library("eurostat")


help(package = "eurostat")

#------------------ searching data about a topic (health) in Eurostat API with search_eurostat()
aa <- search_eurostat("health", type = "all")

#------------------ select some data from Eurostat
my_table <- "hlth_silc_17"          #- we select "hlth_silc_17": "Healthy life expectancy based on self-perceived health"
label_eurostat_tables(my_table)     #- gives information about the table

#------------------ dowloading the selected data with get_eurostat()
df <- get_eurostat(my_table, time_format = 'raw', keepFlags = T )       #- dowloads the table from Eurostat API
df_l <- label_eurostat(df)                                              #- gives labels for the vaiables

#------------------ fixing a little the data
df <- label_eurostat(df, code = c("geo", "unit", "indic_he"))

#- Categorisng the values with cut_to_classes()
df <- df %>%  group_by(indic_he_code) %>% mutate(cat_ind = cut_to_classes(values, n = 4, decimals = 1)) %>% ungroup() %>%
              group_by(sex, indic_he_code) %>% mutate(cat_sex = cut_to_classes(values, n = 4, decimals = 1)) %>% ungroup() %>%
              group_by(time, indic_he_code) %>% mutate(cat_time = cut_to_classes(values, n = 4, decimals = 1)) %>% ungroup() %>%
              group_by(time, sex, indic_he_code) %>% mutate(cat_all = cut_to_classes(values, n = 4, decimals = 1)) %>% ungroup()


#- dowloading the geometries for European countries
geometrias <- get_eurostat_geospatial(resolution = "20", nuts_level = "0")
plot(geometrias, max.plot = 1)

#-  merging the data with the geometries
mapdata <- full_join(df, geometrias, by = c("geo_code" = "id"))




#- select data from 2016, Females & HE_50 ---------------------------------------------------------
mapdata_si <- mapdata %>%  filter(sex == "Females", indic_he_code == "HE_50", time == "2016")

#- 2016, Females, Health expectancy in years at 50
p <- ggplot(mapdata_si) +
     geom_sf(aes(fill = cat_all), color = "black", size = .1) +
     scale_fill_brewer(palette = "RdYlBu")  +
     labs(title = "2016 (Females)",
       subtitle = "Health expectancy in years at 50",
       fill = "Healthy life expectancy",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
     coord_sf(xlim = c(-12,44), ylim = c(35,67))

p


#- select data from 2016, Females & Males and HE_50
#---------------------------------------------------------
mapdata_si <- mapdata %>%  filter(indic_he_code == "HE_50", time == "2016")
#- 2016, Females, Health expectancy in years at 50
p <- ggplot(mapdata_si) +
  geom_sf(aes(fill = cat_ind), color = "black", size = .1) + facet_grid( . ~ sex) +
  scale_fill_brewer(palette = "RdYlBu")  +
  labs(title = "2016",
       subtitle = "Health expectancy in years at 50",
       fill = "Healthy life expectancy",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12,44), ylim = c(35,67))


p

#- select data from Females & HE_50 ---------------------------------------------------------
mapdata_si <- mapdata %>%  filter(indic_he_code == "HE_50", sex == "Females" )
p <- ggplot(mapdata_si) +
  geom_sf(aes(fill = cat_ind), color = "black", size = .1) +
  scale_fill_brewer(palette = "RdYlBu") + facet_wrap( ~ time ) +
  labs(title = "Healthy life expectancy, 2016",
       subtitle = "Health expectancy in years at 50",
       fill = "Healthy",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12,44), ylim = c(35,67))

p


#------ Nuevo gganimate
#- https://gganimate.com/


# install.packages("gganimate")
# install.packages("gapminder")

library(gganimate)
library(gapminder)

theme_set(theme_bw())

#- gráfico estático
p <- ggplot(gapminder, aes(x = gdpPercap, y = lifeExp, size = pop, colour = country)) +
      geom_point(show.legend = FALSE, alpha = 0.7) +
      scale_color_viridis_d() +
      scale_size(range = c(2, 12)) +
      scale_x_log10() +
     labs(x = "GDP per capita", y = "Life expectancy")
p


#- animación
p + transition_time(year) +
  labs(title = "Year: {frame_time}")

#- TAREA: mirar el enlace de abajo
#- https://www.datanovia.com/en/blog/gganimate-how-to-create-plots-with-beautiful-animation-in-r/

#- we could see some more animations:
#- https://gist.github.com/thomasp85/05169ad44ddcc8ed56da6ff7bf7fbe36
#- https://gist.github.com/thomasp85/9362bbfae956f2690794abeb2c11cdcc

#- https://www.brucemeng.ca/post/animations-in-r/

#- spinning globes
# https://www.youtube.com/watch?v=VsyLrCBs0wQ
# http://spatial.ly/2017/05/spinning-globes-with-r/
