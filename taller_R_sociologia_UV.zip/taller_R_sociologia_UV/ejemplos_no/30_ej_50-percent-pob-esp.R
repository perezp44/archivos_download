#- practicar dplyr para curso R
#- vamos a seleccionar los municipios donde vive el 50% de la población
# devtools::install_github("perezp44/spanishRpoblacion")
# devtools::install_github("perezp44/spanishRentidadesIGN")
options(scipen = 999) #- para quitar la notacion científica

library(tidyverse)
library(spanishRpoblacion)
library(spanishRentidadesIGN)
library(personal.pjp)
library(stringr)
library(spanishRshapes)


# aa <- ls("package:spanishRentidadesIGN", all = TRUE) %>% as.data.frame()  #- ves lo que hay en mypkgDataforblog
# help(package = spanishRshapes)



#- cargo datos de población
poblacion <- INE_padron_muni_96_17   # %>% filter(anyo %in% c(2017, 1996)) 

AA <- poblacion

#----------------  50% vs 1% vs 5%
BB <- AA %>% select(INECodMuni, anyo, NombreMuni, Pob_T) %>%  group_by(anyo) %>% arrange(desc(Pob_T)) %>% 
  mutate(Pob_acum = cumsum(Pob_T)) %>% mutate(percent_el = Pob_T/max(Pob_acum)) %>% 
  mutate(percent_acu = Pob_acum/max(Pob_acum)) %>% ungroup()

BB <- BB %>% group_by(anyo) %>% mutate(is_top_50 = if_else(percent_acu <= 0.50, 1, 0)) %>% 
             mutate(is_bottom_1 = if_else(percent_acu >= 0.99, 1, 0)) %>% 
             mutate(is_bottom_5 = if_else(percent_acu >= 0.95, 1, 0))  %>% ungroup()

zz <- BB %>% filter(anyo == 2017) #- veamos los rtdos en 2017



#----------------- provincias con mas % en la capital
CC <- AA %>% group_by(anyo, NombreProv)  %>% 
  mutate(Pob_prov = sum(Pob_T)) %>% 
  mutate(per_pob_prov = Pob_T/Pob_prov) %>% 
  select(NombreMuni, NombreProv, capital_prov, Pob_T, per_pob_prov, Pob_prov)  %>% ungroup()

zz <- CC %>% filter(anyo == 2017) #- veamos los rtdos en 2017


  
  

#- Hacer un grafico gganimate con los municipios 50% por años

#- abajo NO está arreglado


#------------------------------------ MAPAS
#BB <- AA %>% st_set_geometry( NULL)  #- quita la geometria
library(sf)
library(tmap)
library(spanishRshapes)
library(viridisLite)
library(leaflet)

shapes <- IGN_mun_17s #- cargo shape files (8211 recontos)
shapes <- shapes %>% filter(!str_detect(INECodMuni, "^53|^66")  ) #- quito condominios y las islitas de La Gomera





zz_prov <- IGN_prov_17s #- cargo shape files provincial
zz_prov <- zz_prov %>% select(INECodProv, NombreProv, INECodCCAA, NombreCCAA)

zz_b <- zz_prov %>% filter(INECodCCAA == "16")
bb <- aa %>% filter(INECodCCAA == "16")  #- 15 = Navarra; 16 = PV, 10 = Valencia
bb_a <- bb %>% mutate(yes_2_names_A = ifelse(yes_2_names_A == TRUE, "2 nombres", ""))

virpalette <- c("white", "#E41A1C")

pais_vasco <- tm_shape(AA, alpha = 0.3) +
  tm_fill(col = "mas_H", palette = virpalette, title = "mas_H") +
  tm_polygons(border.alpha = 0.6) +
  tm_layout(legend.position = c("left", "bottom"))

pais_vasco <-   pais_vasco + tm_shape(zz_b, alpha = 0.2) + tm_polygons(lwd = 1.8, border.col = "black", alpha = 0.2)






# has de usar este grafico ----------------------------------------------------------
ggplot(data = mpg) +
  geom_boxplot(mapping = aes(x = reorder(class, hwy, FUN = median), y = hwy))
# instalar lvplot pkg  geom_lv()   devtools::install_github("lvplot/hadley")
# otro plo -----------------------------------------
ggplot(data = mpg) +
  geom_violin(mapping = aes(x = reorder(class, hwy, FUN = median), y = hwy)) +
  coord_flip()
# para hecr zoom
coord_cartesian(ylim = c(0, 50))
ifelse()

