
library(SPARQL) # SPARQL querying package
library(ggplot2)
library(tidyverse)
#-------------------------------------------------------------


#- vi esta consulta:  https://twitter.com/TheShubhanshu/status/1109624935662669824
#- asi q la modifique

#- vamos a hacer una consulta a wikidata: http://tinyurl.com/yy6l8u96
SELECT ?politician ?politicianLabel ?country_of_citizenshipLabel ?Twitter_username ?miembro_del_partido_pol_ticoLabel WHERE {
    SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en". }
    ?politician wdt:P31 wd:Q5;
    wdt:P2002 ?Twitter_username;
    wdt:P106 wd:Q82955.
    OPTIONAL { ?politician wdt:P27 ?country_of_citizenship. }
    OPTIONAL { ?politician wdt:P102 ?miembro_del_partido_pol_tico. }
}



#- la misma consulta directamente desde R
#http://www.r-bloggers.com/sparql-with-r-in-less-than-5-minutes/


library(SPARQL) # SPARQL querying package
library(ggplot2)

endpoint <- "https://query.wikidata.org/sparql"
query <- 'SELECT ?politician ?politicianLabel ?country_of_citizenshipLabel ?Twitter_username ?miembro_del_partido_pol_ticoLabel WHERE {\n    SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en". }\n    ?politician wdt:P31 wd:Q5;\n    wdt:P2002 ?Twitter_username;\n    wdt:P106 wd:Q82955.\n    OPTIONAL { ?politician wdt:P27 ?country_of_citizenship. }\n    OPTIONAL { ?politician wdt:P102 ?miembro_del_partido_pol_tico. }\n}\n'

qd <- SPARQL(endpoint,query)
df <- qd$results
#rio::export(df, "./datos/sparql_politics.rds")
import("./datos/sparql_politics.rds")

aa <- df %>% count(country_of_citizenshipLabel) %>% arrange(desc(n))
spanish_politicians <- df %>% filter(country_of_citizenshipLabel == '"Spain"@en')
aa1 <- spanish_politicians %>% count(miembro_del_partido_pol_ticoLabel) %>% arrange(desc(n))






#- Wikidata
#- video de 7 minutos: https://www.youtube.com/watch?v=24DOvuZWaD0

#- https://commons.wikimedia.org/wiki/File:Querying_Wikidata_with_SPARQL_for_Absolute_Beginners.webm


#- some queries
#-  Tributaries of all Italian rivers known to @wikidata as directed graphs. Highlighting: Tiber (Q13712, left) and Po (Q643, right).  http://tinyurl.com/yc8mmyph

#- https://query.wikidata.org/#SELECT%20%28COUNT%28DISTINCT%28%3Fpolitician%29%29%20AS%20%3Fc%29%20%3Fcountry_of_citizenshipLabel%20WHERE%20%7B%0A%20%20SERVICE%20wikibase%3Alabel%20%7B%20bd%3AserviceParam%20wikibase%3Alanguage%20%22%5BAUTO_LANGUAGE%5D%2Cen%22.%20%7D%0A%20%20%3Fpolitician%20wdt%3AP31%20wd%3AQ5.%0A%20%20%3Fpolitician%20wdt%3AP2002%20%3FTwitter_username.%0A%20%20%3Fpolitician%20wdt%3AP106%20wd%3AQ82955.%0A%20%20OPTIONAL%20%7B%20%3Fpolitician%20wdt%3AP27%20%3Fcountry_of_citizenship.%20%7D%0A%7D%0AGROUP%20BY%20%3Fcountry_of_citizenshipLabel%0AORDER%20BY%20DESC%28%3Fc%29
